#ifdef IMAGESTACK_HEADER_1_H
#ifndef IMAGESTACK_HEADER_2_H
// Close the imagestack namespace if we're in it
}
#undef IMAGESTACK_HEADER_1_H
#endif
#endif

#ifdef IMAGESTACK_HEADER_2_H
#ifndef IMAGESTACK_HEADER_3_H
#undef IMAGESTACK_HEADER_2_H
#endif
#endif

#ifdef IMAGESTACK_HEADER_3_H
#ifndef IMAGESTACK_HEADER_4_H
#undef IMAGESTACK_HEADER_3_H
#endif
#endif

#ifdef IMAGESTACK_HEADER_4_H
#ifndef IMAGESTACK_HEADER_5_H
#undef IMAGESTACK_HEADER_4_H
#endif
#endif

#ifdef IMAGESTACK_HEADER_5_H
#ifndef IMAGESTACK_HEADER_6_H
#undef IMAGESTACK_HEADER_5_H
#endif
#endif

#ifdef IMAGESTACK_HEADER_6_H
#ifndef IMAGESTACK_HEADER_7_H
#undef IMAGESTACK_HEADER_6_H
#endif
#endif

#ifdef IMAGESTACK_HEADER_7_H
#ifndef IMAGESTACK_HEADER_8_H
#undef IMAGESTACK_HEADER_7_H
#endif
#endif
