#define XGURU(name) X(plan_guru64_ ## name)
#define IODIM X(iodim64)
#define MKTENSOR_IODIMS X(mktensor_iodims64)
#define GURU_KOSHERP X(guru64_kosherp)
